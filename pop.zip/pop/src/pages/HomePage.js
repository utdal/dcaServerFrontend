import React from 'react';
import Tile from '../components/Tile';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const history = useNavigate();

  const navigateTo = (path) => {
    history.push(path);
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>DCA Server</h2>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '20px' }}>
        <Tile label="EV Coupling" onClick={() => navigateTo('/CoevolvingPairs')} />
        <Tile label="EV Complex" onClick={() => navigateTo('/ev-complex')} />
      </div>
    </div>
  );
};

export default HomePage;